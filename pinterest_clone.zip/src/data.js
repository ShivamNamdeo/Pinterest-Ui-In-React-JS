export const data_list = [
	{
		key:"1",
		img:"https://i.pinimg.com/236x/b0/b1/fe/b0b1fef4957026f5c3f75084af89ce8d.jpg",
		tagline:"Anushka Love Kanha",

	},
	{
		key:"2",
		img:"https://i.pinimg.com/236x/82/06/5a/82065a15f76c27cf751a40dabc08ca63.jpg",
		tagline:"Top IOT Porjects",

	},
	{
		key:"3",
		img:"https://i.pinimg.com/236x/e0/90/3f/e0903f8fcec74ce09ec51dbd1a9adc19.jpg",
		tagline:"Smart Home Automations system",

	},
	{
		key:"4",
		img:"https://i.pinimg.com/236x/e0/52/69/e0526956ec5e69f6003aa74ce957acc5.jpg",
		tagline:"Smart Home Automations system",

	},
	{
		key:"5",
		img:"https://i.pinimg.com/236x/a9/66/b9/a966b9d8470f8054df602beae48d0b6b.jpg",
		tagline:"Smart Home Automations system",

	},
	{
		key:"6",
		img:"https://i.pinimg.com/236x/55/fd/8a/55fd8aa70388a905e3343e56cf59ed43.jpg",
		tagline:"Anushka Love Kanha",

	},

	{
		key:"7",
		img:"https://i.pinimg.com/236x/22/3a/26/223a26a0df09927e8e0d5780e8ae8ab4.jpg",
		tagline:"Smart Home Automations system",

	},
	{
		key:"8",
		img:"https://i.pinimg.com/236x/b1/90/ef/b190ef80335deaf0bd6276b2b68305fe.jpg",
		tagline:"Anushka Love Kanha",

	},

	{
		key:"9",
		img:"https://i.pinimg.com/236x/55/fd/8a/55fd8aa70388a905e3343e56cf59ed43.jpg",
		tagline:"Anushka Love Kanha",

	},
	{
		key:"10",
		img:"https://i.pinimg.com/236x/b1/90/ef/b190ef80335deaf0bd6276b2b68305fe.jpg",
		tagline:"Smart Home Automations system",

	},

	{
		key:"11",
		img:"https://i.pinimg.com/236x/22/3a/26/223a26a0df09927e8e0d5780e8ae8ab4.jpg",
		tagline:"Learn web development",

	},
	{
		key:"12",
		img:"https://i.pinimg.com/236x/b1/90/ef/b190ef80335deaf0bd6276b2b68305fe.jpg",
		tagline:"What is react native",

	},

	{
		key:"13",
		img:"https://i.pinimg.com/236x/22/3a/26/223a26a0df09927e8e0d5780e8ae8ab4.jpg",
		tagline:"How to make dynamic link in firebase",

	},
];

